from django.apps import AppConfig


class NumberGameConfig(AppConfig):
    name = 'number_game'
