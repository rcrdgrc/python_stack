from django.apps import AppConfig


class DojoNinjaAppConfig(AppConfig):
    name = 'dojo_ninja_app'
